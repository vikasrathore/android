package com.cube26.notificationactivationlib;

import android.app.Activity;
import android.os.Bundle;

public class SampleActivity extends Activity{

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        
//        setContentView(R.layout.activity_main);
//        
//        NotificationActivationReceiver.setAlarmForNotificationAndActivation(SampleActivity.this);
    }
}
