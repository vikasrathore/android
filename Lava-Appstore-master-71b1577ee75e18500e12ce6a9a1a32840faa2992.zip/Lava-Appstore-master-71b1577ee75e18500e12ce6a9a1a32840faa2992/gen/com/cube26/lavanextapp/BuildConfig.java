/** Automatically generated file. DO NOT MODIFY */
package com.cube26.lavanextapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}